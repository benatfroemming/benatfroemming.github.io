/*
    A Maze is made up of Cells
 */
public class Cell {
    private boolean visited;    // whether the cell has been visited (true if visited, false if not visited)
    private boolean right;      // whether the cell has a right border (true if a right boundary, false if an open right)
    private boolean bottom;     // whether the cell has a bottom border (true if a bottom boundary, false if an open bottom)
    private boolean solution;   // I created this extra boolean variable (true if the cell is part of the solution, false if not part of the solution)

    // All cells are initialized to full walls
    public Cell(){
        visited = false;
        right = true;
        bottom = true;
        solution = false;
    }

    /**********
     * Setter functions
     **********/
    public void setVisited(boolean visited) { 
        this.visited = visited; 
    }
    public void setRight(boolean right) { 
        this.right = right; 
    }
    public void setBottom(boolean bottom) { 
        this.bottom = bottom; 
    }
    public void setSolution(boolean solution) { 
        this.solution = solution; 
    }
    

    /**********
     * Getter functions
     **********/
    public boolean getVisited() { 
        return visited; }
    public boolean getRight() { 
        return right; }
    public boolean getBottom() { 
        return bottom; }
    public boolean getSolution() { 
        return solution; }
    
}
