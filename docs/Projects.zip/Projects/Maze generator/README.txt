Project members: Benat Froemming (froem076)

- The project following the professors instructions is formed of Cell1.java and MyMaze1.java (this one has the main method).

- I also created the same project modifying it so it is faster and more efficient. It can be found in 
files Cell.java and MyMaze.java. The difference is that instead of creating a new method to solve the maze
using a queue, I solve the maze in the same method I create it in. To do so, I created a new variable
named "solution" in the Cell class. Then, for every time I add a cell to the stack, I make it part of 
the solution. And when I remove it from the stack, I turn this variable back to false. This happens until
we arrive to the end point cell (I use a solved boolean variable in MyMaze to know when we get there). This way,
we get stars only in the correct path without going to dead ends. I think this is much faster.

