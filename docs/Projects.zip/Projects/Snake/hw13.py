import turtle
import random
import time
import winsound #sound effects

# Problems fully completed: A, B and C

# Parts of problem D completed:
# 2: no direction reversal.
#3: auto start two seconds after game over, but can close window when with 'r'.
#4: game speed optimized.
#5: no food pallets spawning inside of the snake.
#6: three different speeds.
#7: I created a point counter, made the background look better with turtle, added sound effects (the grader won't have the file, but it is used during end game and when an apple is eaten).


'''
Purpose: Represents the game structure.
Instance variables: 
- self.player: snake object
Methods: 
- constructor: creates the screen and background, defines keyboard inputs, calles gameloop to start game.
- gameloop: creates a loop every certain time to create the snake motion. It also implements other utilities (sound, end game, etc).
'''


class Game:
    def __init__(self):
        #Setup 700x700 pixel window
        
        turtle.setup(700,700)
        turtle.bgcolor('peru')
        
        #Bottom left of screen is (-40, -40), top right is (640, 640)
        turtle.setworldcoordinates(-40, -40, 640, 640)
        cv = turtle.getcanvas()
        cv.adjustScrolls()
        
        turtle.hideturtle()
        turtle.delay(0)
        turtle.tracer(0, 0)
        turtle.speed(0)

        #Draw the board as a square from (0,0) to (600,600)
        
        turtle.color('white')
        turtle.fillcolor('lightgreen')
        turtle.begin_fill()
        for i in range(20):
            for i in range(10):
                    turtle.forward(30)
                    turtle.left(90) 
                    turtle.forward(30)
                    turtle.right(90)
                    turtle.forward(30)
                    turtle.right(90)
                    turtle.forward(30)
                    turtle.left(90)
            turtle.left(180)
            for i in range(10):
                turtle.forward(30)
                turtle.right(90) 
                turtle.forward(30)
                turtle.left(90)
                turtle.forward(30)
                turtle.left(90)
                turtle.forward(30)
                turtle.right(90)
            turtle.right(90)
            turtle.forward(30)
            turtle.right(90)
        
        turtle.end_fill()  

        turtle.penup()
        turtle.goto(0,-30)
        turtle.write('Press 1 to play in easy mode, press 2 for the intermediate, press 3 fo the fast mode, or press r to exit.' , align="left", font=("candara", 10))


        self.player = Snake(315,315, 'green')
        self.gameloop()

        
        turtle.onkeypress(self.player.go_down, 'Down')
        turtle.onkeypress(self.player.go_up, 'Up')
        turtle.onkeypress(self.player.go_left, 'Left')
        turtle.onkeypress(self.player.go_right, 'Right')
        turtle.onkeypress(self.player.go_right, 'Right')
        turtle.onkeypress(self.player.speedone, '1')
        turtle.onkeypress(self.player.speedtwo, '2')
        turtle.onkeypress(self.player.speedthree, '3')
        turtle.onkeypress(self.player.closegame, 'r') 
        turtle.listen()
        turtle.mainloop()
        

    def gameloop(self):
        
            if self.player.outside() == True: 
                winsound.PlaySound('endgame.wav', winsound.SND_ASYNC)
                turtle.color('black')
                turtle.penup()
                turtle.setposition(150, 275)
                turtle.write('Game Over', font=("candara", 50, "bold"))
                time.sleep(2)
                turtle.undo()
                self.player.restart()
            else:
                self.player.move()
                self.player.counter() 
                if self.player.speed == 1:
                    turtle.ontimer(self.gameloop, 300)
                elif self.player.speed == 2:
                    turtle.ontimer(self.gameloop, 200)
                else:
                    turtle.ontimer(self.gameloop, 100)
                turtle.update()
                


'''
Purpose: Represents the snake character.
Instance variables: 
- self.x: x-axis position.
- self.y: y-axis position.
- self.color: snakes color.
- self.segments: list of snake objects, in other words, list of the snake segments/parts.
- self.vx: x-component of the snake's speed.
- self.vy: y-component of the snake's speed.
- self.coordinates: list of x and y coordinates of apples.
- self.t: turtle object.
- self.ccounter: used to complement the counter function and define each situation.
- self.speed: used to define the snakes speed (3 different speeds).
- self.direction: defines which direction the snake is going, used to avoid going backwards.
- self.apples: list of turtle.apple objects.
Methods: 
- constructor: defines instance variables. Calles the grow and random_position functions.
- closegame: used to close game window/end game.
- grow: creates new snake segment and adds object to self.segments.
- move: changes the position of the snakes head, but first calles the body function. Also checks if the snake eates an apple.
- outside: checks if snake is outside the square or if it each itself, if so, it ends game.
- body: takes current position of all snake segments, then moves each segment to the position of the previous one.
- go_down/go_up/go_left/go_right: change the vx and vy instance variables to change direction of snake. Also helps in the process of avoiding going backwards.
- speedone/speedtwo/speedthree: changes the speed instance variable to change snake speed.
- restart: restarts game.
- random_position: creates apple object and calls set_apple fuction.
- set_apple: creates a random generated coordinates to set apple, but first it checks if the snake isnt there. Also, it adds the coordinates in self.coordinates to check if the snake eates it.
- counter: displays the points/apples eaten on the screen.
'''


class Snake(Game):
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color
        self.segments = [] 
        self.vx = 30
        self.vy = 0
        self.coordinates = []
        self.t = turtle.Turtle()
        self.ccounter = 0 
        self.speed = 1
        self.direction = 0
        self.grow()
        self.random_position() 
        
        
    def closegame(self):
        turtle.bye()

    def grow(self):
        snake = turtle.Turtle()
        snake.fillcolor('deepskyblue')
        snake.speed(0)
        snake.shape('square')
        snake.shapesize(1.5,1.5)
        snake.penup()
        snake.setpos(self.x, self.y)
        snake.setpos(-70, -70)
        self.segments.append(snake)
        

    def move(self):
        self.x += self.vx
        self.y += self.vy
        snake = self.segments[0]
        self.body()
        snake.setpos(self.x, self.y)
        if self.x == self.coordinates[0] and self.y == self.coordinates[1]:
            winsound.PlaySound('apple.wav', winsound.SND_ASYNC)
            self.apple.hideturtle()
            self.random_position()
            self.grow()
                 

        
    def outside(self):
        if self.x >= 600 or self.y >= 600 or self.x <= 0 or self.y <= 0:
            self.ccounter = 2
            self.counter()
            return True

        else:
            list = [] 
            for i in range(0,len(self.segments)):
                j = self.segments[i].pos()
                list.append(j)
            for i in list[1:]:
                if i == list[0]:
                    self.ccounter = 2
                    self.counter()
                    return True
    
            
           
    def body(self):            
        if len(self.segments) > 1:
            list = [] 
            for i in range(0,len(self.segments)-1):
                j = self.segments[i].pos()
                list.append(j)
            for i in range(1,len(self.segments)):
                self.segments[i].goto(list[i-1])


    def go_down(self):
        if len(self.segments) > 1:
            if self.direction != 2:
                self.direction = 3
                self.vx = 0
                self.vy = -30
        else:
            self.direction = 3
            self.vx = 0
            self.vy = -30


    def go_up(self):
        if len(self.segments) > 1:
            if self.direction != 3:
                self.direction = 2
                self.vx = 0
                self.vy = 30
        else:
            self.direction = 2
            self.vx = 0
            self.vy = 30

        

    def go_left(self):
        if len(self.segments) > 1:
            if self.direction != 0:
                self.direction = 1
                self.vx = -30
                self.vy = 0
        else:
            self.direction = 1
            self.vx = -30
            self.vy = 0


    def go_right(self):
        if len(self.segments) > 1:
            if self.direction != 1:
                self.direction = 0
                self.vx = 30
                self.vy = 0
        else:
            self.direction = 0
            self.vx = 30
            self.vy = 0

    
    def speedone(self):
        self.speed = 1

    def speedtwo(self):
        self.speed = 2

    def speedthree(self):
        self.speed = 3

    def restart(self):
        for i in self.segments:
            i.hideturtle()
        for i in self.apples:
            i.hideturtle()
        self.segments = []
        self.apples = []
        
        self.player = Snake(315,315, 'green')
        self.gameloop()

        turtle.onkeypress(self.player.go_down, 'Down')
        turtle.onkeypress(self.player.go_up, 'Up')
        turtle.onkeypress(self.player.go_left, 'Left')
        turtle.onkeypress(self.player.go_right, 'Right')
        turtle.onkeypress(self.player.speedone, '1')
        turtle.onkeypress(self.player.speedtwo, '2')
        turtle.onkeypress(self.player.speedthree, '3') 
        turtle.onkeypress(self.player.closegame, 'r') 
        
        turtle.listen()
        turtle.mainloop()
        
        
    def random_position(self):
        self.apples = []
        self.apple = turtle.Turtle()
        self.apples.append(self.apple)
        self.apple.fillcolor('red')
        self.apple.speed(0)
        self.apple.shape('circle')
        self.apple.shapesize(1.5,1.5)
        self.apple.penup()
        self.set_apple()

    def set_apple(self):
        string = ''    
        x = 15 + 30*random.randint(0,19)
        y = 15 + 30*random.randint(0,19)
        for i in range(0,len(self.segments)):
            a = self.segments[i].xcor()
            b = self.segments[i].ycor()
            if x == a and y == b:
                string = '.'
        if string == '':
            self.apple.setpos(x, y)
            self.coordinates = []
            self.coordinates.append(x)
            self.coordinates.append(y)
        else:
            self.set_apple()
        

    def counter(self):
        score = 1
        if self.ccounter == 0:
            self.score = len(self.segments)
            turtle.color('white')
            turtle.penup()
            turtle.setposition(0,616)
            turtle.write('Score: ' + str(score), align="left", font=("candara", 12, "bold"))
            self.ccounter = 1
        elif self.ccounter == 1:
            turtle.undo()
            score = len(self.segments)
            turtle.color('white')
            turtle.penup()
            turtle.setposition(0,616)
            turtle.write('Score: ' + str(score), align="left", font=("candara", 12, "bold"))
        else:
            turtle.undo()
        
       
Game()