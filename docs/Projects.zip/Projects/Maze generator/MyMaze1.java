// Names: Benat Froemming
// x500s: froem076

import java.util.*;

public class MyMaze1{

    private Cell1[][] maze;
    private int rows;
    private int cols;


    /*
     * Constructor (with int variables rows and cols):
     * Creates an array (rows length) formed of arrays (cols length) with Cell objects, to represent a maze.
     */

    public MyMaze1(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        maze = new Cell1[rows][cols];
        for(int i = 0; i<rows; i++){
            for(int j = 0; j<cols; j++){
                Cell1 cell = new Cell1();
                maze[i][j] = cell; 
            }
        }
    }

    /*
     * makeMaze() method:
     * This method creates a random maze of the desired dimensions, it doesnt return anything.
     * For this it uses a stack of int arrays that represent the coordinates of each cell in the maze. 
     * Firstly, the stack starts with the (0,0) cell, and we set that cell to visited.
     * Then, we loop until the stack is empty.
     * It takes the top cell from the stack and finds all possible neighbors (not visited and inside bounds).
     * For this, I use two arrayLists, and add all possible neighbors to one of them.
     * Then these neighbors go through two filter loops. 
     * When we get all possible neighbors, it randomly chooses one of them and adds its coordinates to the stack.
     * At the same time, it removes the correct wall in between.
     * If there are no possible neighbors, it removes that cell from the stack, this is to create dead ends and make the maze harder.
     * Finally, it calls the solveMaze and printMaze methods.
     */

  
    public void makeMaze() {          
        Stack<int[]> stack = new Stack<int[]>();
        int[] cellIndexes = {0,0};
        stack.push(cellIndexes);
        maze[0][0].setVisited(true);       

        while (stack.empty() == false){

            //gets cell from top of stack
            int[] top = stack.peek();
            
            //finds the cells neighbors
            int[] neighbor1 = {top[0]+1, top[1]};
            int[] neighbor2 = {top[0]-1, top[1]};
            int[] neighbor3 = {top[0], top[1]+1};
            int[] neighbor4 = {top[0], top[1]-1};

            //adds neighbors to an ArrayList
            ArrayList<int[]> neighbors1 = new ArrayList<int[]>();
            ArrayList<int[]> neighbors = new ArrayList<int[]>();
            neighbors1.add(neighbor1);
            neighbors1.add(neighbor2);
            neighbors1.add(neighbor3);
            neighbors1.add(neighbor4);

            //checks if neighbors are inside the bounds and if they are visited, eliminates from ArrayList the ones that can be excluded
            for (int i=0; i<4; i++){
                if ((neighbors1.get(i)[0] >= 0) && (neighbors1.get(i)[1] >= 0) && (neighbors1.get(i)[0] < rows) && (neighbors1.get(i)[1] < cols)){
                    neighbors.add(neighbors1.get(i));
                }
            }
            neighbors1.clear();
            for (int i=0; i<neighbors.size(); i++){
                if (maze[neighbors.get(i)[0]][neighbors.get(i)[1]].getVisited() == false){
                    neighbors1.add(neighbors.get(i));
                }
            }
            neighbors.clear();

            boolean check = false;
            //if there are no unvisited neighbors, it removes top cell, else, it chooses a univisited random neighbor and adds it to the top of stack
            if (neighbors1.isEmpty() == true){
                stack.pop();
                check = true;
            }

            if (check == false){

                int index = (int)(Math.random() * neighbors1.size());
                int[] randNeighbor = neighbors1.get(index);

                stack.push(randNeighbor);
                maze[randNeighbor[0]][randNeighbor[1]].setVisited(true);                 

                //removes corresponding wall
                if (randNeighbor.equals(neighbor1)){
                    maze[top[0]][top[1]].setBottom(false);
                }else if (randNeighbor.equals(neighbor2)){
                    maze[randNeighbor[0]][randNeighbor[1]].setBottom(false);
                }else if (randNeighbor.equals(neighbor3)){
                    maze[top[0]][top[1]].setRight(false);
                }else if (randNeighbor.equals(neighbor4)){
                    maze[randNeighbor[0]][randNeighbor[1]].setRight(false);
                }    
            }             
        }

        for(int i = 0; i<rows; i++){
            for(int j = 0; j<cols; j++){
                maze[i][j].setVisited(false); 
            }
        }

        solveMaze();
        printMaze();
    }
    

    /*
     * solveMaze() method:
     * This method is in charge of solving the maze we generated above, but doesn't return anything.
     * To do so, we use a queue of int arrays of lenth that represent the cell's coordinates, we add (0,0) and set it as visited.
     * A while loop starts until the queue is empty. 
     * Like before, it looks for valid neighbors and instead of choosing a random one, it adds all to the stack.
     * But instead of peeking the queue, this time it also removes it.
     * When it arrives to the end of the maze, the loop breaks.
     */

    public void solveMaze(){

        Queue<int[]> queue = new LinkedList<int[]>();
        int[] cellIndexes = {0,0};
        queue.add(cellIndexes);
        maze[0][0].setVisited(true);  

        while (queue.isEmpty() == false){

            //gets cell from head of queue and removes it, breaks the loop if its the ending cell
            int[] head = queue.remove();
            if (head[0] == rows-1 && head[1] == cols-1){
                break;
            }

            int[] neighbor1 = {head[0]+1, head[1]};
            int[] neighbor2 = {head[0]-1, head[1]};
            int[] neighbor3 = {head[0], head[1]+1};
            int[] neighbor4 = {head[0], head[1]-1};

            //adds neighbors to an ArrayList
            ArrayList<int[]> neighbors1 = new ArrayList<int[]>();
            ArrayList<int[]> neighbors = new ArrayList<int[]>();
            
            neighbors1.add(neighbor1);
            neighbors1.add(neighbor2);
            neighbors1.add(neighbor3);
            neighbors1.add(neighbor4);
            
            //3 loops that filter the neighbors:

            //selects neighbors inside the bounds
            for (int i=0; i<4; i++){
                if ((neighbors1.get(i)[0] >= 0) && (neighbors1.get(i)[1] >= 0) && (neighbors1.get(i)[0] < rows) && (neighbors1.get(i)[1] < cols)){
                    neighbors.add(neighbors1.get(i));
                }
            }
            neighbors1.clear();

            //selects neighbors taking into account the walls
            for (int i=0; i<neighbors.size(); i++){
                if (neighbors.get(i).equals(neighbor3) && maze[head[0]][head[1]].getRight() == false){
                    neighbors1.add(neighbor3);
                }
                if (neighbors.get(i).equals(neighbor4) && maze[neighbor4[0]][neighbor4[1]].getRight() == false){
                    neighbors1.add(neighbor4);
                }
                if (neighbors.get(i).equals(neighbor1) && maze[head[0]][head[1]].getBottom() == false){
                    neighbors1.add(neighbor1);
                }
                if (neighbors.get(i).equals(neighbor2) && maze[neighbor2[0]][neighbor2[1]].getBottom() == false){
                    neighbors1.add(neighbor2);
                }
            }

            neighbors.clear();

            //selects the neighbors that arent visited
            for (int i=0; i<neighbors1.size(); i++){
                if (maze[neighbors1.get(i)[0]][neighbors1.get(i)[1]].getVisited() == false){
                    neighbors.add(neighbors1.get(i));
                }
            }
            neighbors1.clear();
            
            //adds all of the neighbors that passed all filters to the queue 
            for (int i=0; i<neighbors.size(); i++){
                queue.add(neighbors.get(i));
                maze[neighbors.get(i)[0]][neighbors.get(i)[1]].setVisited(true);
            }

        }

    }
    
    /*
     * printMaze() method:
     * This method prints the maze generated above.
     * First it prints the top border (cols length).
     * Then, for every row, it prints two lines.
     * First one is for the walls and solution.
     * Second line is to print the bottom.
     * Note that it makes sure to keep oven (0,0) and (rows-1,cols-1)
     */

    public void printMaze() {

        //prints to top border
        System.out.print("|");
        for (int i = 0; i<cols; i++){
            System.out.print("---|");
        }
        System.out.print("\n");

        //prints maze
        for(int i = 0; i<rows; i++){
            if (i != 0){
                System.out.print("|");
            }else{
                System.out.print(" ");
            }
            for(int j = 0; j<cols; j++){
                if (i == rows-1 && j == cols-1 && maze[i][j].getVisited() == true){
                    System.out.print(" *  ");
                }else if(i == rows-1 && j == cols-1){
                    System.out.print("    ");
                }else if (maze[i][j].getRight() == true && maze[i][j].getVisited() == true){
                    System.out.print(" * |");
                }else if(maze[i][j].getRight() == true){
                    System.out.print("   |");
                }else if(maze[i][j].getVisited() == true){
                    System.out.print(" *  ");
                }else{
                    System.out.print("    ");
                }
            }
            System.out.print("\n");
            System.out.print("|");
            for(int j = 0; j<cols; j++){
                if (maze[i][j].getBottom() == true){
                    System.out.print("---|");
                }else{
                    System.out.print("   |");
                }
            }
            System.out.print("\n");
        }
        
    }

    /*
     * Main method
     * Asks the user for the dimensions of the maze.
     * If the inputed values are 0 or smaller it will warn the user.
     * If the inputed values are valid, it creates a MyMaze object and uses it to call makeMaze().
     */

    public static void main(String[] args){
        Scanner scnr = new Scanner(System.in);
        System.out.println("Enter amount of rows: ");
        int rows = scnr.nextInt();
        System.out.println("Enter amount of columns: ");
        int cols = scnr.nextInt();
        if (cols <= 0 || rows <= 0){
            System.out.println("Enter valid dimensions!");
        }else{
            MyMaze1 mazeObj = new MyMaze1(rows, cols);
            mazeObj.makeMaze();
        }
        scnr.close();

        
    }
}
