Creator: Benat Froemming-Aldanondo (no partners)
The main method is in PlayWordle, so you must run it from here.
I included a txt file of a list of many 5 letter words, which I use in my code.
There should't be any bugs. However, the ANSI colors don't work in the Windows command propt or powershell, so instead of 
words with colors, you'll only be able to see symbols.
Try running the program in the Visual Studio Terminal, it will work there.