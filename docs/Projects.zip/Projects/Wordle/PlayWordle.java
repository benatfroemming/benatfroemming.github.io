//froem076

import java.io.FileNotFoundException;

public class PlayWordle{

    //main method
    public static void main (String [] args) throws FileNotFoundException {
        //creates an object of Wordle
        Wordle play = new Wordle();

        //generates a random word
        play.generateWord();

        //this for loop is to give the user 5 attempts
        //it calls the userInput method as long as the user hasn't won already
        for (int i=0; i<5; i++){
            if (play.winCheck == false){
                play.userInput();
            }        
        }   
    }
}

