//froem076

//imported files, not sure if I use them all

import java.io.IOException;
import java.util.*;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.lang.String;
import java.io.*;

public class Wordle{

    //the random goal word
    private String randomWord;
    //boolean type variable I use to check if the user won
    public boolean winCheck = false;
    //array list of inputed guesses
    private List<String> tries = new ArrayList<>();
    //list of the alphabet
    private String[] alphabet = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
    //I had to implement another alphabet array because of comparison problems, I couldn't update the characters from yellow to green otherwise
    private String[] alphabet1 = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};

    //font and background colors
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED_BACKGROUND = "\u001B[41m";
    public static final String ANSI_GREEN_BACKGROUND = "\u001B[42m";
    public static final String ANSI_YELLOW_BACKGROUND = "\u001B[43m";
    public static final String ANSI_WHITE_BACKGROUND = "\u001B[47m";
    public static final String ANSI_BLACK = "\u001B[30m";

    /*
     * The generateWord method first generates a random integer value not larger than the amount of rows in "five-letter-words.txt".
     * Secondly, it calls this txt file, reads the lines, and asigns the variable 'line' with the random row.
     * After, using a for loop, it checks if the word has duplicate characters, if so, dupChar becomes true.
     * If this is true, the method is called again to keep trying until we get a valid word.
     * Else, we asign the variable 'randomWord' with the 'line' value.
     * I had to do some research online in order to get this working due to an error, so I was able to fix it with the IOException.
     */

    public void generateWord(){

        // boolean dupChar = false;  used to not allow duplicate characters in one word
        try{
            Random rand = new Random();
            int lineNum = rand.nextInt(5756);
            String line = Files.readAllLines(Paths.get("five-letter-words.txt")).get(lineNum);
            randomWord = line;

            //the following loop is not to allow duplicate character words as the random word, which we don't need for this homework.
            //personally, I don't really understand the bonus problem, as it requires less code to allow duplicates, don't really need to change anything if we don't care about it.
            //the actual game allows duplicates, so we aren't making our own version.

            // for (int i = 0; i < line.length(); i++) {
                //             for (int j = i + 1; j < line.length(); j++) {
                //                 if (line.charAt(i) == (line.charAt(j))) {
                //                     dupChar =  true;
                //                 }
                //             }
                //         }
                //         if (dupChar == true){   used to not allow duplicate characters in one word
                //             generateWord();
                //         }else{
                //             randomWord = line;
                //         }
        }

        catch(IOException e){
            System.out.println(e);
        }
    }

    /*
     * The userInput method starts asking the user for a guess, and assigns the input to 'userGuess' in lowercase.
     * After, it checks if the input is a 5 letter word, and if not, it recalls the method to start over.
     * Else, using an if statement, it makes sure the input is an existing word in the txt file using the checkWordExists method.
     * If it does exist, the guess is added to the tries array list, used mainly to keep track of the guesses and print them all.
     * If it does exist, it also checks if its the fifth guess, and if the fifth guess is correct. If not, it shows the correct answer.
     * If it does exist, using the checkWord method, it prints all of the guesses in the list with a color pattern that follows the Wordle game rules.
     * It also prints the alphabet every time when we call the alpha method.
     * If it does not exist, it asks the user for a new word by recalling the itself.
     * I had to do some research online in order to get this working, so I used the FileNotFoundException.
     */

    public void userInput() throws FileNotFoundException{
        System.out.println("Enter a guess:");
        Scanner scnr = new Scanner(System.in);
        String userGuess = scnr.nextLine();
        userGuess = userGuess.toLowerCase();

        if (userGuess.length() != 5){
            System.out.println("Please enter a 5 letter word!");
            userInput();
        }else{
            if (checkWordExists(userGuess) == true){
                tries.add(userGuess);
                if (tries.size() == 5 && !(tries.get(4) == randomWord)){
                    System.out.println("Sorry, you lost! The answer was: " + randomWord);
                }
                for (int i=0; i<tries.size(); i++){
                    checkWord(tries.get(i));
                }
                System.out.println("");
                alpha(userGuess);
    
            }else{
                System.out.println("Enter a valid 5 letter word!");
                userInput();
            }
        }        
    }

    /*
     * The checkWordExists method is used in the userInput method, and passes in a string parameter.
     * Using a scanner, it goes through the txt file to find any matches.
     * I had to do some research online to get this working as I am not that familiar with reading files in java.
     * It returns a boolean answer, true if the word does exist in the txt file.
     */

    public boolean checkWordExists(String guess) throws FileNotFoundException{
        Scanner scnr = new Scanner(new FileInputStream("five-letter-words.txt"));
        while(scnr.hasNextLine()) {
            String line = scnr.nextLine();
            if(line.indexOf(guess)!=-1) {
                return true;
            }        
        }
        return false;
    }

    /*
     * The checkWord method is one of the most important ones in the game, as it is the code for pretty much all the necessary visual output to play besides the instructions.
     * This method is called in the userInput method. Firstly, it passes in the current guess as a string parameter and splits it into a list by character.
     * It does the same with our goal word, and then starts comparing. It prints the word character by character with the correct color, and then prints a new line.
     * Finally, it calls the checkIfWon method, to see if the guess is correct.
     */

    public void checkWord(String guess){
        String[] guessSplit = guess.split("");
        String[] goalWordSplit = randomWord.split("");
        for (int i=0; i < 5; i++){
            if (guessSplit[i].equals(goalWordSplit[i])){
                System.out.print(ANSI_GREEN_BACKGROUND + guessSplit[i] + ANSI_RESET);
            }else if(randomWord.contains(guessSplit[i])){
                System.out.print(ANSI_YELLOW_BACKGROUND + guessSplit[i] + ANSI_RESET);
            }else{
                System.out.print(ANSI_BLACK + ANSI_WHITE_BACKGROUND + guessSplit[i] + ANSI_RESET);
            }
        }
        System.out.println("");
        
        checkIfWon(guess);
    }

    /*
     * The checkIfWon method is used in the checkWord method and it passes in a string of the current guess.
     * It checks if this guess is equal to the goal word, if so it changes the winCheck bollean variable to true.
     */

    public void checkIfWon(String guess){
        if (guess.equals(randomWord)){
            System.out.println("Correct! Good job, you won!");
            winCheck = true;
        }
    }

    /*
     * The alpha method is in charge of updating the alphabet list.
     * I implemented the same for loop but with another loop inside to print out the current status of the keyboard.
     * The first loop gets repeated 5 times, for each letter of the word.
     * The second loop goes through all the alphabet letters. Its the same as in the previous method, but updates tha alphabet letters instead with colors. 
     */
    

    public void alpha(String guess){
        
        String[] guessSplit = guess.split("");
        String[] goalWordSplit = randomWord.split("");
        for (int i=0; i < 5; i++){
            for (int j=0; j < alphabet.length; j++){
                if (guessSplit[i].equals(goalWordSplit[i]) && alphabet1[j].equals(goalWordSplit[i])){
                    alphabet[j] = ANSI_GREEN_BACKGROUND + alphabet1[j] + ANSI_RESET;
                }
                if(randomWord.contains(guessSplit[i]) && alphabet[j].equals(guessSplit[i])){
                    alphabet[j] = ANSI_YELLOW_BACKGROUND + alphabet[j] + ANSI_RESET;
                }
            }
        }
        for (int x=0; x<alphabet.length; x++){
            System.out.print(alphabet[x]);
        }
        System.out.println("");
        System.out.println("");
    }

    
}


